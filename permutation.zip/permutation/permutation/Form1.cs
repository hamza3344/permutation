﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace permutation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static IEnumerable<IEnumerable<T>> GetPermutations<T>(IEnumerable<T> list,int length,bool repeat=false)
        {
            if (length == 1) return list.Select(t => new T[] { t });
            if(repeat==true)
            {
                return GetPermutations(list, length - 1).SelectMany(t => list, (t1, t2) => t1.Concat(new T[] { t2 }));
            }
            else
            {
                return GetPermutations(list, length - 1).SelectMany(t => list.Where(o=>!t.Contains(o)), (t1, t2) => t1.Concat(new T[] { t2 }));
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            List<string> arry = new List<string>();
            textBox2.Text = "";
            foreach(string s in textBox1.Lines)
            {
                arry.Add(s);
            }
            if(String.IsNullOrWhiteSpace(items.Text) || arry.Count()<Convert.ToInt32(items.Text))
            {

            }
            else
            {
                foreach(IEnumerable<string> i in GetPermutations(arry,Convert.ToInt32(items.Text),(rdrno.Checked==true)?false:true))
                {
                    textBox2.AppendText(txtprefix.Text + string.Join(txtdelimiter.Text, i) + txtsuffix.Text);
                    textBox2.AppendText(Environment.NewLine);
                }
                lblitems.Text = (textBox2.Lines.Count() - 1).ToString();
            }
        }
    }
}
